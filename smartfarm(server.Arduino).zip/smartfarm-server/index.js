const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg'); // Postgres 사용

const app = express();
app.use(bodyParser.json());

// Heroku Postgres 데이터베이스 연결 설정
const dbConfig = {
  connectionString: process.env.DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  }
};

const pool = new Pool(dbConfig);

// 데이터 수신 및 DB 저장 엔드포인트
app.post('/update-data', async (req, res) => {
  const { soilMoisture, temperature, humidity, lightLevel } = req.body;

  console.log(`Received data: soilMoisture=${soilMoisture}, temperature=${temperature}, humidity=${humidity}, lightLevel=${lightLevel}`);

  try {
    const result = await pool.query(
      `INSERT INTO SensorData (id, soil_moisture, temperature, humidity, light_level, timestamp) 
       VALUES (1, $1, $2, $3, $4, (CURRENT_TIMESTAMP AT TIME ZONE 'UTC' + INTERVAL '9 hours')::timestamp) 
       ON CONFLICT (id) DO UPDATE 
       SET soil_moisture = EXCLUDED.soil_moisture, 
           temperature = EXCLUDED.temperature,
           humidity = EXCLUDED.humidity,
           light_level = EXCLUDED.light_level,
           timestamp = EXCLUDED.timestamp 
       RETURNING *`,
      [soilMoisture, temperature, humidity, lightLevel]
    );

    res.status(200).json({ success: true, result: result.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 데이터 조회 엔드포인트
app.get('/get-data', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM SensorData');
    res.status(200).json({ success: true, data: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 모터 상태 조회 엔드포인트
app.get('/get-motor-command', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM motorcontrol');
    res.status(200).json({ success: true, data: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 모터 제어 엔드포인트
app.post('/control-motor', async (req, res) => {
  const { water_pump, grow_light, fan } = req.body;

  console.log(`Received data: water_pump=${water_pump}, grow_light=${grow_light}, fan=${fan}`);

  const client = await pool.connect();

  try {
    await client.query('BEGIN');
    let query = 'UPDATE motorcontrol SET ';
    const values = [];
    let valueIndex = 1;

    if (water_pump !== undefined && water_pump !== -1) {
      query += `water_pump = $${valueIndex++}, `;
      values.push(water_pump);
    }
    if (grow_light !== undefined && grow_light !== -1) {
      query += `grow_light = $${valueIndex++}, `;
      values.push(grow_light);
    }
    if (fan !== undefined && fan !== -1) {
      query += `fan = $${valueIndex++}, `;
      values.push(fan);
    }

    if (values.length === 0) {
      throw new Error('No valid values to update');
    }

    query = query.slice(0, -2) + ' WHERE id = 1 RETURNING *';

    const result = await client.query(query, values);

    await client.query('COMMIT');
    res.status(200).json({ success: true, result: result.rows[0] });

  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Database error:', err.stack);
    res.status(500).json({ success: false, error: err.message });
  } finally {
    client.release();
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
