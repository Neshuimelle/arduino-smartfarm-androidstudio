package kr.co.company.smartfarm;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface Api {
    @POST("/update-data")
    Call<SensorResponse> updateData(@Body SensorData data);

    @GET("/get-motor-command")
    Call<MotorControlResponse> getMotorCommand();

    @GET("/get-data")
    Call<SensorResponse> getSensorData();

    @POST("/control-motor") // 서버 API 엔드포인트
    Call<Void> controlMotor(@Body MotorControlRequest request);

}
