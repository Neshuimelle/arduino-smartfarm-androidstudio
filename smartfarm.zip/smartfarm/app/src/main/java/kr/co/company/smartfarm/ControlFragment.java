package kr.co.company.smartfarm;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ControlFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_control, container, false);

        Button btnWaterPump = view.findViewById(R.id.btn_water_pump);
        Button btnGrowLight = view.findViewById(R.id.btn_grow_light);
        Button btnFan = view.findViewById(R.id.btn_fan);

        // 제어 버튼 클릭 리스너 설정
        btnWaterPump.setOnClickListener(v -> {
            getActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.nav_host_fragment, new WaterPumpControlFragment())
                    .addToBackStack(null)
                    .commit();
        });

        btnGrowLight.setOnClickListener(v -> {
            getActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.nav_host_fragment, new GrowLightControlFragment())
                    .addToBackStack(null)
                    .commit();
        });

        btnFan.setOnClickListener(v -> {
            getActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.nav_host_fragment, new FanControlFragment())
                    .addToBackStack(null)
                    .commit();
        });

        return view;
    }
}