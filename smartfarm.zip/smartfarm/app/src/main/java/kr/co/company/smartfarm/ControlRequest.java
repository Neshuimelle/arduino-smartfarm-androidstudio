package kr.co.company.smartfarm;

public class ControlRequest {
    private boolean waterPump;
    private int growLight;
    private boolean fan;

    public ControlRequest(boolean waterPump, int growLight, boolean fan) {
        this.waterPump = waterPump;
        this.growLight = growLight;
        this.fan = fan;
    }

    public boolean isWaterPump() {
        return waterPump;
    }

    public void setWaterPump(boolean waterPump) {
        this.waterPump = waterPump;
    }

    public int getGrowLight() {
        return growLight;
    }

    public void setGrowLight(int growLight) {
        this.growLight = growLight;
    }

    public boolean isFan() {
        return fan;
    }

    public void setFan(boolean fan) {
        this.fan = fan;
    }
}