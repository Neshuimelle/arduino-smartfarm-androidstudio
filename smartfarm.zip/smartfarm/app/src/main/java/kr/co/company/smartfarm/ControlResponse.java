package kr.co.company.smartfarm;

public class ControlResponse {
    private ControlState action;

    public ControlState getAction() {
        return action;
    }

    public void setAction(ControlState action) {
        this.action = action;
    }
}
