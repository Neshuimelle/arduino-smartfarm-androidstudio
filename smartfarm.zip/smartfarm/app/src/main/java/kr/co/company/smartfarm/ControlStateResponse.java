package kr.co.company.smartfarm;

public class ControlStateResponse {
    private ControlState data;

    public ControlState getData() {
        return data;
    }

    public void setData(ControlState data) {
        this.data = data;
    }
}


