package kr.co.company.smartfarm;

import android.os.Handler;
import android.util.Log;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ControlViewModel extends ViewModel {

    private Api apiService;
    private MutableLiveData<Integer> waterPumpData = new MutableLiveData<>();
    private MutableLiveData<Integer> growLightData = new MutableLiveData<>();
    private MutableLiveData<Integer> fanData = new MutableLiveData<>();
    private Handler handler;
    private Runnable fetchDataRunnable;
    private boolean isUserInteracting = false;

    public ControlViewModel() {
        apiService = RetrofitClient.getInstance().getApi();
        handler = new Handler();
        fetchDataRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isUserInteracting) {
                    fetchControlData();
                }
                handler.postDelayed(this, 3000); // 3초마다 데이터 갱신
            }
        };
        handler.post(fetchDataRunnable);
    }

    public LiveData<Integer> getWaterPumpData() {
        return waterPumpData;
    }

    public LiveData<Integer> getGrowLightData() {
        return growLightData;
    }

    public LiveData<Integer> getFanData() {
        return fanData;
    }

    public void setUserInteracting(boolean interacting) {
        isUserInteracting = interacting;
    }

    private void fetchControlData() {
        apiService.getMotorCommand().enqueue(new Callback<MotorControlResponse>() {
            @Override
            public void onResponse(Call<MotorControlResponse> call, Response<MotorControlResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    MotorControlResponse data = response.body();
                    if (data.isSuccess() && data.getData() != null && !data.getData().isEmpty()) {
                        MotorControlResponse.MotorData motorData = data.getData().get(0);
                        Log.d("ControlViewModel", "Fetched data: " + data);
                        Log.d("ControlViewModel", "Fetched data - WaterPump: " + motorData.getWaterPump() + ", GrowLight: " + motorData.getGrowLight() + ", Fan: " + motorData.getFan());
                        waterPumpData.setValue(motorData.getWaterPump());
                        growLightData.setValue(motorData.getGrowLight());
                        fanData.setValue(motorData.getFan());
                    } else {
                        Log.e("ControlViewModel", "Invalid data in response");
                    }
                } else {
                    Log.e("ControlViewModel", "Failed to fetch data: " + response.message());
                    if (response.errorBody() != null) {
                        try {
                            Log.e("ControlViewModel", "Error body: " + response.errorBody().string());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<MotorControlResponse> call, Throwable t) {
                Log.e("ControlViewModel", "Failed to fetch data", t);
            }
        });
    }



    public void controlWaterPump(int speedpump) {
        Log.d("ControlViewModel", "Sending waterPumpSpeed: " + speedpump);
        controlMotor(speedpump, -1, -1);
    }

    public void controlGrowLight(int brightness) {
        Log.d("ControlViewModel", "Sending growLightValue: " + brightness);
        controlMotor(-1, brightness, -1);
    }

    public void controlFan(int speedfan) {
        Log.d("ControlViewModel", "Sending fanSpeed: " + speedfan);
        controlMotor(-1, -1, speedfan);
    }

    private void controlMotor(int waterPumpSpeed, int growLightValue, int fanSpeed) {
        MotorControlRequest request = new MotorControlRequest();
        request.setWaterPump(waterPumpSpeed);
        request.setGrowLight(growLightValue);
        request.setFan(fanSpeed);

        Call<Void> call = apiService.controlMotor(request);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Log.d("ControlViewModel", "Motor control success");
                } else {
                    Log.e("ControlViewModel", "Motor control failed: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Log.e("ControlViewModel", "Motor control failed: " + t.getMessage());
            }
        });
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        handler.removeCallbacks(fetchDataRunnable);
    }
}
