package kr.co.company.smartfarm;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.appcompat.widget.SwitchCompat;

public class GrowLightControlFragment extends Fragment {

    private ControlViewModel controlViewModel;
    private SeekBar seekBarGrowLight;
    private SwitchCompat switchAuto;
    private boolean isUserInteracting = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_grow_light_control, container, false);

        Button buttonBack = view.findViewById(R.id.button_back_grow_light);
        seekBarGrowLight = view.findViewById(R.id.seekBarGrowLight);
        switchAuto = view.findViewById(R.id.switchAutoGrowLight);

        controlViewModel = new ViewModelProvider(this).get(ControlViewModel.class);

        controlViewModel.getGrowLightData().observe(getViewLifecycleOwner(), new Observer<Integer>() {
            @Override
            public void onChanged(Integer value) {
                if (!isUserInteracting && value != null) {
                    if (value == 256) {
                        switchAuto.setChecked(true);
                        seekBarGrowLight.setEnabled(false);
                    } else {
                        seekBarGrowLight.setProgress(value);
                        switchAuto.setChecked(false);
                        seekBarGrowLight.setEnabled(true);
                    }
                }
            }
        });

        buttonBack.setOnClickListener(v -> getActivity().onBackPressed());

        seekBarGrowLight.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    controlViewModel.controlGrowLight(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                isUserInteracting = true;
                controlViewModel.setUserInteracting(true);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                isUserInteracting = false;
                controlViewModel.setUserInteracting(false);
                controlViewModel.controlGrowLight(seekBar.getProgress());
            }
        });

        switchAuto.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                seekBarGrowLight.setEnabled(false);
                controlViewModel.controlGrowLight(256); // 자동 모드로 설정
            } else {
                seekBarGrowLight.setEnabled(true);
                controlViewModel.controlGrowLight(seekBarGrowLight.getProgress());
            }
        });

        return view;
    }
}
