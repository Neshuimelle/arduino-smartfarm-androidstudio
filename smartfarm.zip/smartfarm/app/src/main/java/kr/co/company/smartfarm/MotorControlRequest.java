package kr.co.company.smartfarm;

import com.google.gson.annotations.SerializedName;

public class MotorControlRequest {

    @SerializedName("water_pump")
    private int waterPump;

    @SerializedName("grow_light")
    private int growLight;

    @SerializedName("fan")
    private int fan;

    // Getters and setters
    public int getWaterPump() {
        return waterPump;
    }

    public void setWaterPump(int waterPump) {
        this.waterPump = waterPump;
    }

    public int getGrowLight() {
        return growLight;
    }

    public void setGrowLight(int growLight) {
        this.growLight = growLight;
    }

    public int getFan() {
        return fan;
    }

    public void setFan(int fan) {
        this.fan = fan;
    }
}
