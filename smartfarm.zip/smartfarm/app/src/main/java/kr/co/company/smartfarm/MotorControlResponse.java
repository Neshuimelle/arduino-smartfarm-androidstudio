package kr.co.company.smartfarm;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class MotorControlResponse {

    @SerializedName("success")
    private boolean success;

    @SerializedName("data")
    private List<MotorData> data;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public List<MotorData> getData() {
        return data;
    }

    public void setData(List<MotorData> data) {
        this.data = data;
    }

    public static class MotorData {
        @SerializedName("id")
        private int id;

        @SerializedName("water_pump")
        private int waterPump;

        @SerializedName("grow_light")
        private int growLight;

        @SerializedName("fan")
        private int fan;

        // Getters and setters
        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getWaterPump() {
            return waterPump;
        }

        public void setWaterPump(int waterPump) {
            this.waterPump = waterPump;
        }

        public int getGrowLight() {
            return growLight;
        }

        public void setGrowLight(int growLight) {
            this.growLight = growLight;
        }

        public int getFan() {
            return fan;
        }

        public void setFan(int fan) {
            this.fan = fan;
        }
    }
}
