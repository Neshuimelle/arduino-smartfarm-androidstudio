package kr.co.company.smartfarm;

import java.util.List;

public class SensorResponse {
    private List<SensorData> data;

    public List<SensorData> getData() {
        return data;
    }

    public void setData(List<SensorData> data) {
        this.data = data;
    }
}
