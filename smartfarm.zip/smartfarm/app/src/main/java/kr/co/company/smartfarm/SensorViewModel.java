package kr.co.company.smartfarm;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import android.os.Handler;
import android.util.Log;

import java.util.List;

public class SensorViewModel extends ViewModel {

    private MutableLiveData<List<SensorData>> sensorData;
    private Handler handler;
    private Runnable fetchDataRunnable;

    public SensorViewModel() {
        sensorData = new MutableLiveData<>();
        handler = new Handler();
        fetchDataRunnable = new Runnable() {
            @Override
            public void run() {
                fetchSensorData();
                handler.postDelayed(this, 3000); // 3초마다 데이터 갱신
            }
        };
        handler.post(fetchDataRunnable);
    }

    public LiveData<List<SensorData>> getSensorData() {
        return sensorData;
    }

    private void fetchSensorData() {
        RetrofitClient.getInstance().getApi().getSensorData().enqueue(new Callback<SensorResponse>() {
            @Override
            public void onResponse(Call<SensorResponse> call, Response<SensorResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<SensorData> dataList = response.body().getData();
                    sensorData.setValue(dataList);
                    if (dataList != null && !dataList.isEmpty()) {
                        for (SensorData data : dataList) {
                            Log.d("SensorViewModel", "Received data - Soil Moisture: " + data.getSoilMoisture() +
                                    ", Light Level: " + data.getLightLevel());
                        }
                    }
                    Log.d("SensorViewModel", "Data received: " + response.body().getData().toString());
                } else {
                    Log.d("SensorViewModel", "No data received");
                }
            }

            @Override
            public void onFailure(Call<SensorResponse> call, Throwable t) {
                Log.d("SensorViewModel", "Failed to fetch data", t);
            }
        });
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        handler.removeCallbacks(fetchDataRunnable);
    }
}
