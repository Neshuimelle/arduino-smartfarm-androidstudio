package kr.co.company.smartfarm;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.util.Log;
import java.util.List;

public class SensorsFragment extends Fragment {

    private SensorViewModel sensorViewModel;
    private TextView soilMoistureValue, temperatureValue, humidityValue, lightLevelValue;

    public SensorsFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_sensors, container, false);

        soilMoistureValue = view.findViewById(R.id.soil_moisture_value);
        temperatureValue = view.findViewById(R.id.temperature_value);
        humidityValue = view.findViewById(R.id.humidity_value);
        lightLevelValue = view.findViewById(R.id.light_level_value); // 조도 센서

        sensorViewModel = new ViewModelProvider(this).get(SensorViewModel.class);
        sensorViewModel.getSensorData().observe(getViewLifecycleOwner(), new Observer<List<SensorData>>() {
            @Override
            public void onChanged(List<SensorData> sensorData) {
                if (sensorData != null && !sensorData.isEmpty()) {
                    SensorData latestData = sensorData.get(0);
                    Log.d("SensorsFragment", "Soil Moisture: " + latestData.getSoilMoisture());
                    soilMoistureValue.setText(latestData.getSoilMoisture());
                    temperatureValue.setText(latestData.getTemperature() + "°C");
                    humidityValue.setText(latestData.getHumidity() + "%");
                    lightLevelValue.setText(latestData.getLightLevel()); // 조도 값 설정
                    Log.d("SensorsFragment", "Sensor data updated");
                } else {
                    Log.d("SensorsFragment", "No sensor data available");
                }
            }
        });

        return view;
    }
}
