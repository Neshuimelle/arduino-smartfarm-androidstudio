package kr.co.company.smartfarm;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.appcompat.widget.SwitchCompat;

public class WaterPumpControlFragment extends Fragment {

    private ControlViewModel controlViewModel;
    private SeekBar seekBarWaterPump;
    private SwitchCompat switchAuto;
    private boolean isUserInteracting = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_water_pump_control, container, false);

        Button buttonBack = view.findViewById(R.id.button_back_water_pump);
        seekBarWaterPump = view.findViewById(R.id.seekBarWaterPump);
        switchAuto = view.findViewById(R.id.switchAutoWaterPump);

        // ViewModel 초기화
        controlViewModel = new ViewModelProvider(this).get(ControlViewModel.class);

        // waterPumpData LiveData 옵저버 설정
        controlViewModel.getWaterPumpData().observe(getViewLifecycleOwner(), new Observer<Integer>() {
            @Override
            public void onChanged(Integer value) {
                if (!isUserInteracting && value != null) {
                    if (value == 256) {
                        switchAuto.setChecked(true);
                        seekBarWaterPump.setEnabled(false);
                    } else {
                        seekBarWaterPump.setProgress(value);
                        switchAuto.setChecked(false);
                        seekBarWaterPump.setEnabled(true);
                    }
                }
            }
        });

        // 뒤로가기 버튼 클릭 리스너 설정
        buttonBack.setOnClickListener(v -> getActivity().onBackPressed());

        // SeekBar 변경 리스너 설정
        seekBarWaterPump.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    controlViewModel.controlWaterPump(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                isUserInteracting = true;
                controlViewModel.setUserInteracting(true);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                isUserInteracting = false;
                controlViewModel.setUserInteracting(false);
                controlViewModel.controlWaterPump(seekBar.getProgress());
            }
        });

        // SwitchCompat 변경 리스너 설정
        switchAuto.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                seekBarWaterPump.setEnabled(false);
                controlViewModel.controlWaterPump(256); // 자동 모드로 설정
            } else {
                seekBarWaterPump.setEnabled(true);
                controlViewModel.controlWaterPump(seekBarWaterPump.getProgress());
            }
        });

        return view;
    }
}
